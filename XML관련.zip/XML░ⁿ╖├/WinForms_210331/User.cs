﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinForms_210331
{
    class User
    {
        public int Carnum { get; set; }
        public string Name { get; set; }
    }
}
