﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace WinForms_210331
{
    public partial class Form1 : Form
    {
        private List<Book> listBooks = new List<Book>();
        private List<User> listUsers = new List<User>();        

        public Form1()
        {
            InitializeComponent();
            Read_Book();
            Read_User();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Make_Books();
            Make_Users();
        }

        private void Make_Books()
        {
            // 도서 XML 생성
            string booksOutput = "";
            booksOutput += "<books>\n";
            foreach (var item in listBooks)
            {
                booksOutput += "<book>\n";
                booksOutput += "  <isbn>" + item.isbn + "</isbn>\n";
                booksOutput += "  <name>" + item.Name + "</name>\n";
                booksOutput += "  <publisher>" + item.Publisher + "</publisher>\n";
                booksOutput += "  <page>" + item.Page + "</page>\n";
                booksOutput += "  <borrowedAt>" + item.BorrowedAt.ToLongDateString() + "</borrowedAt>\n";
                booksOutput += "  <isBorrowed>" + (item.isBorrowed ? 1 : 0) + "</isBorrowed>\n";
                booksOutput += "  <userId>" + item.UserId + "</userId>\n";
                booksOutput += "  <userName>" + item.UserName + "</userName>\n";
                booksOutput += "</book>\n";
            }
            booksOutput += "</books>";

            File.WriteAllText(@"./Books.xml", booksOutput);
        }

        private void Make_Users()
        {
            // 사용자 XML 생성
            string usersOutput = "";
            usersOutput += "<users>\n";
            foreach (var item in listUsers)
            {
                usersOutput += "<user>\n";
                usersOutput += "  <id>" + item.Carnum + "</id>\n";
                usersOutput += "  <name>" + item.Name + "</name>\n";
                usersOutput += "</user>\n";
            }
            usersOutput += "</users>";

            // 저장

            File.WriteAllText(@"./Users.xml", usersOutput);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Read_Book();
            Read_User();
        }

        private void Read_Book()
        {
            try
            {
                FileInfo fib = new FileInfo(@"./Books.xml");

                if (!fib.Exists)
                {
                    MessageBox.Show("Books.xml 파일이 존재하지 않습니다.");
                    return;
                }

                listBooks.Clear();

                string booksOutput = File.ReadAllText(@"./Books.xml");
                XmlDocument xdocBook = new XmlDocument();
                xdocBook.Load(@"./Books.xml");
                XmlNodeList nodeBooks = xdocBook.SelectNodes("/books/book");
                foreach (XmlNode book in nodeBooks)
                {
                    listBooks.Add(new Book()
                    {
                        Isbn = book.SelectSingleNode("isbn").InnerText,
                        Name = book.SelectSingleNode("name").InnerText,
                        Publisher = book.SelectSingleNode("publisher").InnerText,
                        Page = int.Parse(book.SelectSingleNode("page").InnerText),
                        BorrowedAt = DateTime.Parse(book.SelectSingleNode("borrowedAt").InnerText),
                        isBorrowed = book.SelectSingleNode("isBorrowed").InnerText != "0" ? true : false,
                        UserId = int.Parse(book.SelectSingleNode("userId").InnerText),
                        UserName = book.SelectSingleNode("userName").InnerText,
                    });
                }
            }
            catch (FileLoadException exception)
            {
                // 파일이 없으면 예외 발생: 새로운 파일 생성
                Make_Books();
            }
            
        }

        private void Read_User()
        {
            try
            {
                FileInfo fiu = new FileInfo(@"./Users.xml");

                if (!fiu.Exists)
                {
                    MessageBox.Show("Users.xml 파일이 존재하지 않습니다.");
                    return;
                }

                listUsers.Clear();

                XmlDocument xdocUser = new XmlDocument();
                xdocUser.Load(@"./Users.xml");
                XmlNodeList nodeUsers = xdocUser.SelectNodes("/users/user");
                foreach (XmlNode user in nodeUsers)
                {
                    listUsers.Add(new User()
                    {
                        Carnum = int.Parse(user.SelectSingleNode("id").InnerText),
                        Name = user.SelectSingleNode("name").InnerText,
                    });
                }

            }
            catch (FileLoadException exception)
            {
                // 파일이 없으면 예외 발생: 새로운 파일 생성
                Make_Users();
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView2.DataSource = null;
            dataGridView1.DataSource = listBooks;
            dataGridView2.DataSource = listUsers;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != " " || textBox2.Text != " ")
            {
                int output;
                if(int.TryParse(textBox1.Text,out output))
                listUsers.Add(new User()
                {
                    Carnum = output,
                    Name = textBox2.Text
                });

                dataGridView2.DataSource = null;
                dataGridView2.DataSource = listUsers;
            }



        }
    }
}
